package com.klef.jfsd.springboot;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.List;

@Service
public class WeatherServiceImpl implements WeatherService {

    @Value("${openweathermap.api.key}")
    private String apiKey;

    private final WeatherDataRepository weatherDataRepository;
    private final RestTemplate restTemplate;

    @Autowired
    public WeatherServiceImpl(WeatherDataRepository weatherDataRepository, RestTemplate restTemplate) {
        this.weatherDataRepository = weatherDataRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    public WeatherData getWeatherData(String city) {
        // Construct the API URL
        String apiUrl = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey;

        // Send a request to the OpenWeatherMap API and retrieve the response
        OpenWeatherMapResponse response = restTemplate.getForObject(apiUrl, OpenWeatherMapResponse.class);

        if (response != null) {
            // Create a WeatherData entity and save it to the database
            WeatherData weatherData = new WeatherData();
            weatherData.setCity(city);
            weatherData.setDescription(response.getWeather().get(0).getDescription());
            weatherData.setTemperature(response.getMain().getTemp());
            weatherData.setTimestamp(new Date());

            weatherDataRepository.save(weatherData);

            return weatherData;
        } else {
            // Handle the case where the API response is null
            return null;
        }
    }

    @Override
    public List<WeatherData> getAllWeatherData() {
        return weatherDataRepository.findAll();
    }
}
