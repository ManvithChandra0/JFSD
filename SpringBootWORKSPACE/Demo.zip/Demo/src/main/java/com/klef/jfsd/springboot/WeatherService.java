package com.klef.jfsd.springboot;



import java.util.List;

public interface WeatherService {
    WeatherData getWeatherData(String city);
    List<WeatherData> getAllWeatherData();
}
